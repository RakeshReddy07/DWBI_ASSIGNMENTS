create database assignment1;
use assignment1;
CREATE TABLE [Emp](
	[BusinessEntityID] [varchar](100) NOT NULL,
	[NationalIDNumber] [varchar](90) NOT NULL,
	[LoginID] [varchar](256) NOT NULL,
	[OrganizationNode] [varchar](70) NULL,
	[OrganizationLevel] [varchar](80) NOT NULL,
	[JobTitle] [varchar](50) NOT NULL,
	[BirthDate] [varchar](70) NOT NULL,
	[MaritalStatus] [varchar](60) NOT NULL,
	[Gender] [varchar](60) NOT NULL,
	[HireDate] [varchar](90) NOT NULL,
	[SalariedFlag] [varchar](90) NOT NULL,
	[VacationHours] [varchar](90) NOT NULL,
	[SickLeaveHours] [varchar](90) NOT NULL,
	[CurrentFlag] [varchar](90) NOT NULL,
	[rowguid] [varchar](90) NOT NULL,
	[ModifiedDate] [varchar](90)NOT NULL,
)
drop table Emp;
select * from Emp;